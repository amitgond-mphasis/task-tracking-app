import React from 'react';
import { Link } from 'react-router-dom';

import Main from '../layouts/Main';

const Index = () => (
  <Main
    description={"Michael D'Angelo's personal website. New York based Stanford ICME graduate, "
      + 'VP of Engineering at Smile Identity, co-founder of Arthena and Matroid, and YC Alumni.'}
  >
    <article className="post" id="index">
      <header>
        <div className="title">
          <h2><Link to="/">About this site</Link></h2>
          <p>
            hello i'm Amit kumar gond, a passionate and highly skilled freelancer specializing in  mern full stack devlopment . With a proven track record of delivering exceptional results, I am
            committed to providing top notch services that exeed your expetations.</p>


          <h5>Why choose me:</h5>
          <p>
            <li>I have one year of experience in mern full stack development i have honed my skills to perfection. i stay updated on industry trends and technolgoies to offer cutting egde solutions.
            </li>
            <li>Quality assurance I priotize in every project. My attention to details ensures that the final deliverables meet the highest standsrds.. your satisfaction is my top priority.</li>
            <li>Effective communication clear and open communication is crucial  for successfull collabaration i am rsponsive attentie  and committed to keeping you informed throught the project lifecycle.</li>
          </p>

          <h5>service  i offer:</h5>
          <p>
            <li>Help you to provide the best IT solution for your business.</li>
            <li>Develop website for your firm.</li>
            <li>Provide techincal supports.</li>

          </p>


          <h5>How I work:</h5>
          <p>
            <li><b>Understanding Your Needs:</b>I start by throughly understnding  your requirements and objectives to ensure a
              trailored solution.</li>
            <li><b>Timely Delivery:</b> I adhere to deadlines and prioritize timely delivery without compormising on quality.</li>
            <li><b>Feedback Integration:</b> Your feedback is invaluable. I welcome input and iterate based on your suggestions to achieve perfection.</li>

          </p>

          <p>Let's Get Started:
            Ready to elevate your project? contact me today, and let's discuss how i can bring your vision to life. I look forward to the opportunity to work with you!

          </p>
        </div>
      </header>
      <p> Welcome to my website. Please feel free to read more <Link to="/about">about me</Link>,
        or you can check out my {' '}
        <Link to="/resume">resume</Link>, {' '}
        <Link to="/projects">projects</Link>, {' '}
        view <Link to="/stats">site statistics</Link>, {' '}
        or <Link to="/contact">contact</Link> me.
      </p>
      <p> Source available <a href="https://github.com/amitgond-mphasis">here</a>.</p>
    </article>
  </Main>
);

export default Index;
