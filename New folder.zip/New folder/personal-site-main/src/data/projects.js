// TODO Add a couple lines about each project
const data = [
  {
    title: 'Task Tracking Application',
    subtitle: '2015 BVP Hackathon',
    image: '/images/projects/taskTracking.png',
    date: '2015-11-20',
    desc:
      'Task tracking applicalication is a tool designed to streamline task management within your organization.'
      + 'With focus of simplicity and efficiency,the application allows administrators to assign task to agent and enable agents to update the status of assigned tasks. '
      + 'JWT is implemented for secure and seamless user authentication.',
  },
  {
    title: 'Event Management Application',
    subtitle: 'Won 3rd. place in 2015 Techcrunch Disrupt SF Hackathon',
    link: 'https://devpost.com/software/harvest',
    image: '/images/projects/harvest.jpg',
    date: '2015-09-20',
    desc:
      'Event Management Application designed to simplify the process of organizing and managing competitions and events.'
      + 'This application caters to a contests, and more.'
      +'It empowers administrators to create events, allows participants to register, and enables judges to evaluate performances and determine winners through a rating system.'
      ,
  },
  // {
  //   title: 'S',
  //   subtitle: 'A kickstarter funded potato powered weather balloon.',
  //   link: 'http://www.spacepotato.org',
  //   image: '/images/projects/spacepotato.jpg',
  //   date: '2015-06-28',
  //   desc:
  //     'Launched a potato battery powered weather balloon with two cameras '
  //     + 'and gps transponder. Resulting photos were published in a coffee table book. '
  //     + 'You can email me for a copy.',
  // },
  // {
  //   title: 'Web Crawling',
  //   subtitle: 'A convolutional neural network to classify cats! (and dogs)',
  //   image: '/images/projects/catdetector.jpg',
  //   date: '2015-05-15',
  //   desc:
  //     'Trained a convolutional neural network to classify between ~ 80 cats breeds. '
  //     + 'Over 60,000 cats were classified before server bills made the project too expensive '
  //     + 'to continue hosting.',
  // },
];

export default data;
