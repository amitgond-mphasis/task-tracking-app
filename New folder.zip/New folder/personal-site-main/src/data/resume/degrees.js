const degrees = [
  {
    school: 'Indian Institute of Technology Kharagpur',
    degree: 'M.Tech. Computer Science and Engineering',
    link: 'https://www.iitkgp.ac.in/',
    year: 2023,
  },
  {
    school: 'B.I.E.T Jhansi',
    degree: 'B.Tech. Information Technology',
    link: 'http://bietjhs.ac.in/',
    // year: 2012,
  },
];

export default degrees;
